'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "main.dart.js": "7837ed65bf13a3f8b2b36cc4943287bd",
"index.html": "43bee57064ae811bab2a10f4e28f400d",
"/": "43bee57064ae811bab2a10f4e28f400d",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"favicon.png": "5e49dc7541545fdf375764896895ee4e",
"manifest.json": "09e188d3814907d06d27d804861ea0b2",
"assets/i18n/ko.json": "324f79b6b8561ed15369a3c42541c2c3",
"assets/i18n/en.json": "639a5586dac8d514f9f95eafb8f91c21",
"assets/AssetManifest.json": "eb4416160e3665058f0c143585cded64",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "6d342eb68f170c97609e9da345464e5e",
"assets/fonts/MaterialIcons-Regular.otf": "4e6447691c9509f7acdbf8a931a85ca1",
"assets/NOTICES": "7f868d562ee579a137bcd306726f55b8",
"assets/assets/images/print_menu.png": "032ddb6f045e3f8bd29c0bf7f191fbcd",
"assets/assets/images/wifi_not_connect.png": "ab4d30543867746512bbb75d4f7358be",
"assets/assets/images/file1.png": "4e9462f0db10b09f888ed413363ed46c",
"assets/assets/images/top.png": "1dbdeb8e9381576241001ad125187d8a",
"assets/assets/images/floor.png": "80e0a2829f5ac6b5c0e2693ecfdd035a",
"assets/assets/images/calibrate.png": "0372dba5a50a72a85f4fd32d9aceadf3",
"assets/assets/images/lcd.png": "0173123105716644518dbe37b742d002",
"assets/assets/images/splash.mp4": "d53dcae229454228903b82f00147d62f",
"assets/assets/images/disconnect.png": "33ad878350a794646a9ab649e176a9f9",
"assets/assets/images/right_arrow.png": "0662ac0f53d3c3f52fcbca9188ddca71",
"assets/assets/images/search.png": "9c4fd65c39ed93011a2a5ba99097b436",
"assets/assets/images/resin.png": "272e7d1d284dec223a647274c5a8108e",
"assets/assets/images/splash.gif": "485e5882233f018d8b670c01ecbbe59e",
"assets/assets/images/zaxis.png": "6803debe9eca8a0e6206aa2446373a98",
"assets/assets/images/setting_menu.png": "8040527af78e2e5e854a464da420cc77",
"assets/assets/images/jobs_list.png": "efd9b3960a4b9562bfd1b46860d2f443",
"assets/assets/images/file2.png": "63e0c712a1eee02de70fe55fe1d22d5b",
"assets/assets/images/network.png": "06d18e0b1b51c23a56354e4b1f625a27",
"assets/assets/images/left_arrow.png": "74221c14b79b0d336eb87bf1215244cd",
"assets/assets/images/submit.png": "505d69b84cb2b0faed268b88f0fb662b",
"assets/assets/images/printer.png": "78a13fa52ba55e8ec0d0ca30d0eb5487",
"assets/assets/images/print.png": "7a4d00c72f409da7ee8e25af06d22fa9",
"assets/assets/images/how_to_use.png": "b1a746e88a086ddec82c93225d0e518b",
"assets/assets/images/help_menu.png": "6817aa2125ec2a095b712a0cb6cb5efe",
"assets/assets/images/logo.png": "91b85809b3f40651540b8953afd76807",
"assets/assets/images/edit_icon.png": "6f4ff3747b7e909d1598e161eaa2b7e0",
"assets/assets/images/woman.png": "d06fea7365d7b04daedec5ce118a3b7f",
"assets/assets/images/splash.webm": "cda43582ce713e8ac90c09a9b2888b35",
"assets/assets/images/woman_complete.png": "daa803103b43205f0789c12539049469",
"assets/assets/images/delete.png": "f27cbd8b0c7a1469587e1f96b0944f13",
"assets/assets/images/wifi_connect.png": "45d5fe59b541acb11aed573616dcd7bc",
"assets/assets/images/new_job.png": "6e809740c5f96b920f071392ecde53c5",
"assets/assets/images/qrcode.png": "b329e2d5d8f0cb168725c68dfca58598",
"assets/assets/images/ask_help.png": "4df810e7c8cf4b809e642a6a3adfe16d",
"assets/assets/config.json": "ad26c05936337ae10f69c6789a2d793c",
"assets/FontManifest.json": "dc3d03800ccca4601324923c0b1d6d57",
"version.json": "a3dabe73cf4aeca556dee04e97283178"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "/",
"main.dart.js",
"index.html",
"assets/NOTICES",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache.
        return response || fetch(event.request).then((response) => {
          cache.put(event.request, response.clone());
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
