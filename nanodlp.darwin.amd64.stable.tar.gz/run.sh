#!/bin/bash
sudo ./nanodlp